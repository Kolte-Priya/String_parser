package com.parser;

import java.util.ArrayList;
import java.util.List;

public class SayHello {

	private String name;
	List <resultObject> objlist;
	
	public SayHello()
	{
		this.objlist=new ArrayList<>();
	}
	public List<resultObject> getObjlist() {
		return objlist;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println(name);
		this.name = name;
	}
	
	//method to send message
	public String execute()
	{
		
		TesterAPI object= new TesterAPI();
		
		objlist=object.funParser(name, true);
		if(objlist!=null)
		{
			for(resultObject o:objlist)
			{
				System.out.println(o.getKeyword()+":"+o.getRelatedWords());
			}
		}
		return "success";
	}
	
}
