package com.parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import net.didion.jwnl.JWNL;
import net.didion.jwnl.JWNLException;
import net.didion.jwnl.data.IndexWord;
import net.didion.jwnl.data.POS;
import net.didion.jwnl.data.Synset;
import net.didion.jwnl.data.Word;
import net.didion.jwnl.dictionary.Dictionary;


public class JWNLtester {
	public JWNLtester()
	{
		super();
	}
	
	public static void jwnlcheckword(String word) 
	{
		// Initialize JWNL
        try {
			JWNL.initialize(new FileInputStream("C:\\Users\\priya\\eclipse-workspace\\jars\\jwnl14-rc2\\config\\file_properties.xml"));
		
        // Get the dictionary
        Dictionary dictionary = Dictionary.getInstance();

        // Look up the word "dog"
        IndexWord w;
		
			w = dictionary.lookupIndexWord(POS.NOUN, word);
		 

        // Get all of the synsets for the word
        Synset[] synsets;
		
			synsets = w.getSenses();
			System.out.println("JWNL lib!!!!");
			 for (Synset synset : synsets) {
		            for (Word synonym : synset.getWords()) {
		                System.out.println(synonym.getLemma());
		            }
		        }
		} 
        catch (FileNotFoundException | JWNLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		

        // Print out all of the synonyms for each synset
       
   
	}
}
