package com.parser;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import edu.mit.jwi.Dictionary;
import edu.mit.jwi.IDictionary;
import edu.mit.jwi.item.IIndexWord;
import edu.mit.jwi.item.ISynset;
import edu.mit.jwi.item.IWord;
import edu.mit.jwi.item.IWordID;
import edu.mit.jwi.item.POS;

//import net.sf.jwnl.JWNL;
//import net.sf.jwnl.data.Dictionary;
//import net.sf.jwnl.data.Synset;

public class TesterAPI {
	public List<resultObject> funParser(String name,boolean status)
	{
		ArrayList<String> propernouns=new ArrayList<>();
		ArrayList<String> finalKeywords=new ArrayList<>();
	//	List<List<String>> wordsWithSynonyms=new ArrayList<>();
		List<resultObject> relatedWordList=new ArrayList<>();
		try {
		
	       
	        for (int i = 0; i < name.length(); i++) {
	            for (int j = i + 1; j <= name.length(); j++) {
	                String keyword = name.substring(i, j);
	               System.out.println(keyword);
	                if(keyword.indexOf(" ")!=-1)
	                {
	                //System.out.println("Whiter space hai!!");
	                keyword=keyword.replaceAll("//s","");
	                }
	                
	                if(keyword.length()>3){
	                	
	                		if(checkWord(keyword))
	                			{
	                				if(!(finalKeywords.contains(keyword))){
	                					finalKeywords.add(keyword);
	                					//wordsWithSynonyms.add(get_synonyms(keyword));
	                					relatedWordList.add(get_synonymsobject(keyword));
	                					}
	                			}
	                		else {
	                		propernouns.add(keyword);
	                	}
	                
	            }
	                else {
	                	continue;
	                }
	        }
	        
		}
		}
		catch (Exception e) {
        	System.out.println("In exception!!!");
        	e.printStackTrace();
        	}
   
       if(status && !finalKeywords.isEmpty())
       {
    	   System.out.println("Final keywords="+finalKeywords);
   
       }
       else {
    	//   System.out.println(propernouns);
       }
      //System.out.println("leftout="+propernouns);
		//return "Hello Priya , REST API!"+name;
     //  return wordsWithSynonyms;
       return relatedWordList;
	}
	//function with jwnl lib to check the word is present in dictionary or not

	// function to check the given word is present in the wordnet dicitonary.
				public boolean checkWord(String word)
				{
					String wordNetPath = "C:\\Users\\priya\\eclipse-workspace\\TestParser\\WebContent\\WEB-INF\\lib\\dict";
					POS[] posArray= {POS.ADJECTIVE,POS.ADVERB,POS.NOUN,POS.VERB};
					IDictionary dict = new Dictionary(new File(wordNetPath));
				        try {
				            	dict.open();
				            	int flag=0;
				            	for(POS pos:posArray)
				            	{
				            		if(dict.getIndexWord(word, pos) != null)
				            		{
				            			flag=1;
				            			System.out.println(word+" "+pos);
				            			//return true;
				            		}
				            	}
				            	if(flag==1)
				            	{
				            		return true;
				            	}
				            	dict.close();
				        	} 
				        catch (Exception e) 
				        {
				            e.printStackTrace();
				        } 
				        finally 
				        {
				            // Close the dictionary
				            if (dict != null) 
				            {
				                dict.close();
				            }
				        }
				       // JWNLtester.jwnlcheckword(word);
				        return false;
				}
				public List<String> get_synonyms(String wordtoLookUp)
				{
					
					Set<String> synonyms = new HashSet<>();
					
					try {
						String wordNetPath = "C:\\Users\\priya\\eclipse-workspace\\TestParser\\WebContent\\WEB-INF\\lib\\dict";
						
						IDictionary dict = new Dictionary(new File(wordNetPath));
			            dict.open();
			            // Get all synsets for the word
			            POS[] posArray= {POS.ADJECTIVE,POS.ADVERB,POS.NOUN,POS.VERB};
			            for(POS pos:posArray)
		            	{
			            IIndexWord idxWord = dict.getIndexWord(wordtoLookUp, pos);
			            
			            if (idxWord != null) {
			            	
			                for (IWordID wordID : idxWord.getWordIDs()) {
			                    IWord word = dict.getWord(wordID);
			                    ISynset synset = word.getSynset();
			                  
			                    for (IWord synWord : synset.getWords()) {
			                        String wordstr=synWord.getLemma().toLowerCase();
			                        //!(wordstr.contains("_")||
			                        
			                        if(wordstr.contains("-"))
			                        {
			                        	String newStr = wordstr.replaceAll("-","");
			                        	
			                              synonyms.add(newStr);
			                        }
			                        else if(wordstr.contains("_"))
			                        {
			                        	String newStr = wordstr.replaceAll("_","");
			                        	
			                              synonyms.add(newStr);
			                        }
			                        else {
			                        
			                        synonyms.add(wordstr);
			                        }
			                    }
			                    
			                }
			            }
			          	}
			            dict.close();
					 } catch (Exception e) {
				            e.printStackTrace();
				        }
					List<String> myList = new ArrayList<>(synonyms);
					myList.remove(myList.indexOf(wordtoLookUp));
					myList.add(0, wordtoLookUp);
					return myList;
					//make hashmap here where keyword is key and list of synonmys and other forms is its value
				}
				
				
				public resultObject get_synonymsobject(String wordtoLookUp)
				{
					
					Set<String> synonyms = new HashSet<>();
					
					try {
						String wordNetPath = "C:\\Users\\priya\\eclipse-workspace\\TestParser\\WebContent\\WEB-INF\\lib\\dict";
						
						IDictionary dict = new Dictionary(new File(wordNetPath));
			            dict.open();
			            // Get all synsets for the word
			            POS[] posArray= {POS.ADJECTIVE,POS.ADVERB,POS.NOUN,POS.VERB};
			            for(POS pos:posArray)
		            	{
			            IIndexWord idxWord = dict.getIndexWord(wordtoLookUp, pos);
			            
			            if (idxWord != null) {
			            	
			                for (IWordID wordID : idxWord.getWordIDs()) {
			                    IWord word = dict.getWord(wordID);
			                    ISynset synset = word.getSynset();
			                  
			                    for (IWord synWord : synset.getWords()) {
			                        String wordstr=synWord.getLemma().toLowerCase();
			                        //!(wordstr.contains("_")||
			                        
			                        if(wordstr.contains("-"))
			                        {
			                        	String newStr = wordstr.replaceAll("-","");
			                        	
			                              synonyms.add(newStr);
			                        }
			                        else if(wordstr.contains("_"))
			                        {
			                        	String newStr = wordstr.replaceAll("_","");
			                        	
			                              synonyms.add(newStr);
			                        }
			                        else {
			                        
			                        synonyms.add(wordstr);
			                        }
			                    }
			                    
			                }
			            }
			          	}
			            dict.close();
					 } catch (Exception e) {
				            e.printStackTrace();
				        }
					resultObject obj=new resultObject();
					
					
					List<String> myList = new ArrayList<>(synonyms);
					myList.remove(myList.indexOf(wordtoLookUp));
					//myList.add(0, wordtoLookUp);
					
					obj.setKeyword(wordtoLookUp);
					obj.setRelatedWords(myList);
					
					return obj;
					//make hashmap here where keyword is key and list of synonmys and other forms is its value
				}

}
